﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace DiceOut
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public int[] Dice = new int[3];
        public int Score = 0;
        public int Score2 = 0;

        public Random RandomGenerator = new Random();

        public MainPage()
        {
            this.InitializeComponent();
            SetupGame();
        }

        private void SetupGame()
        {
            WinText.Text = "Click the \"Roll Die\" button, or preferably choose which card you want before the game with the buttons below";
            ScoreText.Text = $"Your Score: {Score}, Computer Score: {Score2}";
        }

        private void RollButton_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < Dice.Length; i++)
            {
                int DieValue = RandomGenerator.Next(1, 7);
                Dice[i] = DieValue;
            }

            Die1.DisplayFace(Dice[0]);
            Die2.DisplayFace(Dice[1]);
            Die3.DisplayFace(Dice[2]);

            ApplyGameRules();
        }

        private void ApplyGameRules()
        {
            int NewScore = 0;
            int NewScore2 = 0;
            string WinMessage = "";

            if (Dice[0] < Dice[1])
            {

                NewScore2 = (Dice[0] + Dice[1]) * 100; 
                WinMessage = $"Computer Wins because  {Dice[0]} is less than {Dice[1]} points.";

            }


            else if (Dice[0] > Dice[1])
            {
                NewScore = (Dice[0] + Dice[1]) * 100;
                WinMessage = $"Congratulations, you win! {Dice[0]} is greater than {Dice[1]} points.";


            }
            else
            {
                NewScore = 0;
                WinMessage = "It's a draw, try again";
            }

            Score = Score + NewScore;
            Score2 = Score2 + NewScore2;
            ScoreText.Text = $"Your Score: {Score}, Computer Score: {Score2}";
            WinText.Text = WinMessage;
        }

        private void ApplyGameRules2()
        {
            int NewScore = 0;
            int NewScore2 = 0;
            string WinMessage = "";

            if (Dice[1] < Dice[2])
            {

                NewScore2 = (Dice[1] + Dice[2]) * 100;
                WinMessage = $"Computer Wins because  {Dice[1]} is less than {Dice[2]} points.";

            }


            else if (Dice[1] > Dice[2])
            {
                NewScore = (Dice[1] + Dice[2]) * 100;
                WinMessage = $"Congratulations, you win! {Dice[1]} is greater than {Dice[2]} points.";


            }
            else
            {
                NewScore = 0;
                WinMessage = "It's a draw, try again";
            }

            Score = Score + NewScore;
            Score2 = Score2 + NewScore2;
            ScoreText.Text = $"Your Score: {Score}, Computer Score: {Score2}";
            WinText.Text = WinMessage;
        }


        private void ApplyGameRules3()
        {
            int NewScore = 0;
            int NewScore2 = 0;
            string WinMessage = "";

            if (Dice[2] < Dice[1])
            {

                NewScore2 = (Dice[2] + Dice[1]) * 100;
                WinMessage = $"Computer Wins because  {Dice[2]} is less than {Dice[1]} points.";

            }


            else if (Dice[1] > Dice[2])
            {
                NewScore = (Dice[2] + Dice[1]) * 100;
                WinMessage = $"Congratulations, you win! {Dice[2]} is greater than {Dice[1]} points.";


            }
            else
            {
                NewScore = 0;
                WinMessage = "It's a draw, try again";
            }

            Score = Score + NewScore;
            Score2 = Score2 + NewScore2;
            ScoreText.Text = $"Your Score: {Score}, Computer Score: {Score2}";
            WinText.Text = WinMessage;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < Dice.Length; i++)
            {
                int DieValue = RandomGenerator.Next(1, 7);
                Dice[i] = DieValue;
            }

            Die1.DisplayFace(Dice[0]);
            Die2.DisplayFace(Dice[1]);
            Die3.DisplayFace(Dice[2]);

            ApplyGameRules();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < Dice.Length; i++)
            {
                int DieValue = RandomGenerator.Next(1, 7);
                Dice[i] = DieValue;
            }

            Die1.DisplayFace(Dice[0]);
            Die2.DisplayFace(Dice[1]);
            Die3.DisplayFace(Dice[2]);

            ApplyGameRules2();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < Dice.Length; i++)
            {
                int DieValue = RandomGenerator.Next(1, 7);
                Dice[i] = DieValue;
            }

            Die1.DisplayFace(Dice[0]);
            Die2.DisplayFace(Dice[1]);
            Die3.DisplayFace(Dice[2]);

            ApplyGameRules3();

        }
    }
}
